import React from 'react';

export default function InventoryActivity() {
  return (
    <div style={{ padding: 24 }}>
      <h2>Inventory Activity</h2>
      <p>This is a placeholder page for Inventory Activity logs.</p>
    </div>
  );
}
