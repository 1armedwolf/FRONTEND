import React from 'react';
import Sidebar from "../../components/sidebar/sidebar";
import "./home.scss";
import Widget from "../../components/widget/admininventorywidgets";
import Table from "../../components/table/Table"; 
import SearchBar from "../../components/search/SearchBar";

const BranchBalance = () => {
  const [refreshKey, ] = React.useState(0);
  const [searchTerm, setSearchTerm] = React.useState('');


  return (
    <div className="dashboard">
      <Sidebar />
      <div className="dashboardContainer">
        
        <div className="widgets">
          <Widget type="Branch Total Item" />
          <Widget type="Branch Total Items Amount" />
        </div>
        
        <div className="listContainer">
          <div className="inventoryHeaderRow">
            <h2 className="listTitle">Branch Inventory</h2>
            <SearchBar
              value={searchTerm}
              onChange={setSearchTerm}
              placeholder="Search branch inventory..."
            />
          </div>
          
          <Table refreshKey={refreshKey} searchTerm={searchTerm} />
        </div>
      </div>
    </div>
  );
};

export default BranchBalance;